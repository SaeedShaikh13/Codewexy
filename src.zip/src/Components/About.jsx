import React from "react";
import styles from "../Styles/Global.module.css";
const About = () => {
  return (
    <div className={styles.Body}>
      <p>
        <h2>About us:-</h2> Lorem ipsum dolor sit, amet consectetur adipisicing
        elit. Sit veniam tempora harum, ratione dignissimos aut, illum dolorum
        provident dicta corrupti laborum! Veniam quasi earum quod voluptatem,
        cum modi alias. Aliquam, saepe dignissimos totam aliquid maxime ratione
        rerum ad rem ea porro, debitis hic harum iste aspernatur tempora
        mollitia doloribus magni commodi maiores natus! Vero asperiores nulla
        natus nostrum ipsam accusamus atque, laudantium quam alias earum. Eaque
        adipisci dolores quod, rerum molestias corrupti officiis! Minima
        corrupti debitis optio tenetur vitae tempora asperiores veritatis quidem
        animi magni. Assumenda quasi quae eum aliquid atque quisquam quaerat
        deleniti, nesciunt saepe accusamus inventore laboriosam voluptates.{" "}
      </p>
    </div>
  );
};

export default About;
